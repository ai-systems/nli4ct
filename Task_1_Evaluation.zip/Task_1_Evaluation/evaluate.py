#!/usr/bin/env python3

import json
import os
import os.path
import sys
import warnings
from sklearn.metrics import f1_score,precision_score,recall_score

warnings.simplefilter('ignore')


def main():

    input_dir = sys.argv[1]
    output_dir = sys.argv[2]
    pred_dir = os.path.join(input_dir, 'res')
    gold_dir = os.path.join(input_dir, 'ref')

    if not os.path.isdir(pred_dir):
        raise RuntimeError('{} does not exist'.format(pred_dir))

    if not os.path.isdir(gold_dir):
        raise RuntimeError('{} does not exist'.format(gold_dir))

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    gold_filename = os.path.join(gold_dir, 'Gold_test.json')
    pred_filename = os.path.join(pred_dir, 'results.json')

    with open(pred_filename) as json_file:
        results= json.load(json_file)

    with open(gold_filename) as json_file:
        gold = json.load(json_file)

    uuid_list = list(results.keys())

    results_pred = []
    gold_labels = []
    for i in range(len(uuid_list)):
        if results[uuid_list[i]]["Prediction"] == "Entailment":
            results_pred.append(1)
        else:
            results_pred.append(0)
        if gold[uuid_list[i]]["Label"] == "Entailment":
            gold_labels.append(1)
        else:
            gold_labels.append(0)

    f_score = f1_score(gold_labels,results_pred)
    p_score = precision_score(gold_labels,results_pred)
    r_score = recall_score(gold_labels,results_pred)

    output_filename = os.path.join(output_dir, 'scores.txt')
    with open(output_filename, 'w') as f:
        print('F1:{:f}'.format(f_score), file=f)
        print('precision_score:{:f}'.format(p_score), file=f)
        print('recall_score:{:f}'.format(r_score), file=f)

if '__main__' == __name__:
    main()










